# AI Blocker 1.2.1 — Public beta package

**A more human internet.**

AI Blocker is a local-first browser extension prototype that hides page elements when their visible text or accessible metadata contains strong signals of AI generation. It provides Light, Balanced and Aggressive modes, restore/rescan controls, trusted-site allowlisting, blocked-domain overlays and local preferences.

## Downloads in this kit
- `AI_Blocker_Chromium_1.2.1.zip` — Chrome, Edge and Chromium-compatible browsers (manual developer-mode installation).
- `AI_Blocker_Firefox_1.2.1.zip` — Firefox temporary add-on build. It is unsigned and not a permanent install.
- `AI_Blocker_Public_Release_Kit_1.2.1.zip` — source, documentation and both browser packages.

## Install on Chrome or Edge (desktop)
1. Download and extract the Chromium ZIP.
2. Open `chrome://extensions` or `edge://extensions`.
3. Enable Developer mode.
4. Select **Load unpacked** and choose the extracted `extension_chromium` folder.

## Install on Firefox (temporary)
1. Extract the Firefox ZIP.
2. Open `about:debugging` → **This Firefox**.
3. Choose **Load Temporary Add-on** and select `manifest.json`.
4. Firefox removes temporary add-ons when it closes. Store signing and a permanent add-on ID are still required.

## What it detects today
The detector uses rules against visible text, alt text, titles, ARIA labels and selected generation metadata attributes. Explicit disclosures and synthetic-media labels are strong signals. A tool name on its own is weak evidence.

## What it does not do
This build does **not** run a trained image model, inspect image pixels, sample video frames, classify audio waveforms, or identify unlabeled AI media reliably. It cannot filter native mobile apps. It can miss AI content and hide human content by mistake. Filtering support varies by website. This is a beta utility, not a guarantee of authenticity.

## Privacy and permissions
The extension does not include analytics or extension-managed network requests. Preferences and counters are stored in browser local storage. The broad website access permission is required for page scanning and is sensitive; users should install only if comfortable granting it. The extension does not upload page content to a detection server.

## Before commercial release
A trained and validated media classifier, independent security review, real-world false-positive/false-negative testing, browser compatibility testing, support contact, legal/privacy review, and marketplace approval remain outstanding. Do not market this build as detecting all AI content.
