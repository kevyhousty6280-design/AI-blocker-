# Publishing checklist

## Before a beta listing
- [ ] Run install and interaction tests on current Chrome, Edge and Firefox versions
- [ ] Capture genuine screenshots from tested builds
- [ ] Review broad host permission and store privacy disclosures
- [ ] Add a monitored support contact and hosted privacy policy
- [ ] Replace temporary Firefox add-on ID and submit for signing
- [ ] Check product name and trademark availability

## Before a paid/commercial launch
- [ ] Integrate and validate a licensed local image classifier
- [ ] Decide whether video/audio analysis is technically and legally viable
- [ ] Build a representative benchmark and publish measured precision/recall
- [ ] Complete independent security and privacy review
- [ ] Add crash/performance monitoring only with clear consent and disclosure
- [ ] Prepare refund, support, terms and consumer-law processes

## Submission destinations
- Chrome Web Store: https://chrome.google.com/webstore/devconsole
- Microsoft Edge Add-ons: https://partner.microsoft.com/dashboard
- Firefox Add-ons: https://addons.mozilla.org/developers/
- GitHub Releases: https://github.com/

Platform accounts, identity verification, fees, review and publication are controlled by each platform. This package has not been uploaded or approved.
