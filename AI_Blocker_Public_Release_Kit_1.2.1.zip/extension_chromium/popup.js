const $ = id => document.getElementById(id);
chrome.storage.local.get({ enabled: true, mode: 'balanced', blockedCount: 0 }, s => {
  $('enabled').checked = s.enabled; $('mode').value = s.mode; $('count').textContent = s.blockedCount || 0;
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => { const tab = tabs[0]; if (!tab?.id) return; chrome.tabs.sendMessage(tab.id, { type: 'status' }, status => { if (!chrome.runtime.lastError && status) $('count').textContent = status.hidden; }); });
});
$('enabled').addEventListener('change', () => chrome.storage.local.set({ enabled: $('enabled').checked }));
$('mode').addEventListener('change', () => chrome.storage.local.set({ mode: $('mode').value }));
async function send(type) { const [tab] = await chrome.tabs.query({ active: true, currentWindow: true }); if (tab?.id) chrome.tabs.sendMessage(tab.id, { type }, () => { void chrome.runtime.lastError; }); }
$('restore').addEventListener('click', () => send('restore'));
$('rescan').addEventListener('click', () => send('scan'));
$('settings').addEventListener('click', () => chrome.runtime.openOptionsPage());
