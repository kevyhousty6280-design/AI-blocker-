(() => {
  // Evidence-based rules: labels are stronger than mentions of tools. This is not a pixel classifier.
  const rules = [
    { id: 'explicit-disclosure', re: /\b(?:this (?:image|photo|video|audio|voice|content) (?:was )?ai[- ]generated|ai[- ]generated (?:image|photo|video|audio|voice|content)|generated (?:entirely )?by ai|made with ai|created with ai|synthetic media)\b/i, score: 100, kind: 'explicit', reason: 'Explicit AI-generation disclosure' },
    { id: 'synthetic-label', re: /\b(?:deepfake|synthetic (?:image|video|audio|voice)|ai avatar|generated avatar|virtual influencer)\b/i, score: 90, kind: 'explicit', reason: 'Synthetic-media label' },
    { id: 'ai-tool', re: /\b(?:midjourney|stable diffusion|dall[ -]?e(?:\s*\d+)?|sora|runway(?:ml)?|veo|suno|udio|elevenlabs|adobe firefly|flux(?:\.\w+)?)\b/i, score: 42, kind: 'tool', reason: 'AI generation tool mentioned' },
    { id: 'generation-workflow', re: /\b(?:text[- ]to[- ]image|text[- ]to[- ]video|image prompt|negative prompt|prompt generated|ai image generator|ai video generator)\b/i, score: 54, kind: 'workflow', reason: 'AI generation workflow described' },
    { id: 'voice-disclosure', re: /\b(?:ai voice|voice clone|cloned voice|speech synthesis|synthetic narrator)\b/i, score: 88, kind: 'explicit', reason: 'Synthetic-audio signal' },
    { id: 'metadata', re: /\b(?:comfyui workflow|automatic1111|generated with stable diffusion|novelai metadata|midjourney xmp job|c2pa generative claim)\b/i, score: 96, kind: 'metadata', reason: 'Generation metadata signal' }
  ];
  function inspectText(text = '') {
    const hits = []; let score = 0; let toolHits = 0; let workflowHits = 0;
    for (const rule of rules) {
      if (!rule.re.test(String(text))) continue;
      hits.push({ id: rule.id, reason: rule.reason, score: rule.score, kind: rule.kind });
      if (rule.kind === 'tool') toolHits++;
      if (rule.kind === 'workflow') workflowHits++;
      score = Math.max(score, rule.score);
    }
    // A named tool alone is weak. Combined workflow evidence is stronger but remains below
    // the default balanced threshold, avoiding blocks for incidental tool discussion.
    if (toolHits && workflowHits) score = Math.max(score, 72);
    return { score, hits, reasons: hits.map(h => h.reason), label: score >= 90 ? 'high-signal' : score >= 70 ? 'likely-ai' : score >= 40 ? 'weak-signal' : 'no-signal' };
  }
  window.AIBlockerDetector = { inspectText, rules: rules.map(({ id, score, kind, reason }) => ({ id, score, kind, reason })) };
})();
