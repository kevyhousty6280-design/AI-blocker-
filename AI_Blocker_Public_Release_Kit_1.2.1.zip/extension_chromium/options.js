const $ = id => document.getElementById(id);
const defaults = { allowDomains: [], blockDomains: [] };
function clean(value) {
  const entries = value.split(/\r?\n/).map(s => s.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').replace(/\/$/, ''));
  return Array.from(new Set(entries.filter(s => s && !s.includes('/') && !s.includes(' ') && s.includes('.') && !s.includes('..'))));
}
chrome.storage.local.get({ ...defaults, types: { text: true, images: true, video: true, audio: true } }, s => { $('allow').value = (s.allowDomains || []).join('\n'); $('block').value = (s.blockDomains || []).join('\n'); const t = s.types || {}; for (const key of ['text','images','video','audio']) $('type-'+key).checked = t[key] !== false; });
$('save').addEventListener('click', () => chrome.storage.local.set({ allowDomains: clean($('allow').value), blockDomains: clean($('block').value), types: { text: $('type-text').checked, images: $('type-images').checked, video: $('type-video').checked, audio: $('type-audio').checked } }, () => { $('saved').textContent = 'Saved on this device.'; }));
$('export').addEventListener('click', () => chrome.storage.local.get(null, s => { const blob = new Blob([JSON.stringify(s, null, 2)], { type: 'application/json' }); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'ai-blocker-preferences.json'; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000); }));
$('reset').addEventListener('click', () => chrome.storage.local.set({ enabled: true, mode: 'balanced', types: { text: true, images: true, video: true, audio: true }, allowDomains: [], blockDomains: [], blockedCount: 0 }, () => { $('allow').value = ''; $('block').value = ''; for (const key of ['text','images','video','audio']) $('type-'+key).checked = true; $('saved').textContent = 'Defaults restored.'; }));
