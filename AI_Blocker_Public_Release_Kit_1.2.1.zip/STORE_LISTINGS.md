# Store listing copy

## Name
AI Blocker – Human Content Filter

## Short description
Hide posts with strong AI-generation signals using local, rule-based filtering.

## Long description
AI Blocker helps reduce AI-labelled and AI-related content in your browsing feed. Choose Light, Balanced, or Aggressive filtering, restore hidden content, rescan pages, and manage trusted sites.

Filtering is performed locally using visible text and accessible metadata. This prototype is not a trained AI detector: it does not classify image pixels, video frames, or audio. Results can be missed or incorrectly flagged. Site compatibility varies.

## Privacy summary
The extension stores settings locally and does not include analytics or extension-managed network requests. Its broad host permission is required to scan content on websites and is sensitive.

## Search terms
AI filter, AI content, human content, feed filter, content filter, synthetic media, privacy

## Screenshots required before submission
1. Popup with filtering modes
2. Hidden-content indicator on a test page
3. Restore/rescan controls
4. Trusted-site controls
5. Settings and signal toggles

Do not use simulated screenshots as real product screenshots. Capture from a tested browser build.
