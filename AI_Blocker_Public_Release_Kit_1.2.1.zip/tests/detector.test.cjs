const fs = require('node:fs');
const vm = require('node:vm');
const src = fs.readFileSync('extension_chromium/detector.js', 'utf8');
const sandbox = { window: {} };
vm.runInNewContext(src, sandbox);
const inspect = sandbox.window.AIBlockerDetector.inspectText;
const tests = [
  ['explicit disclosure is high confidence', 'This image was AI-generated', 100],
  ['deepfake label is high confidence', 'Warning: deepfake video', 90],
  ['tool name alone is weak', 'I use Midjourney for some projects', 42],
  ['tool plus workflow is stronger but below balanced', 'Midjourney text-to-image prompt', 72],
  ['ordinary prose has no signal', 'A lovely day walking along the coast', 0],
  ['synthetic voice label is strong', 'AI voice and cloned voice demo', 88],
  ['metadata signal is high', 'ComfyUI workflow attached', 96],
];
let failed = 0;
for (const [name, input, expected] of tests) {
  const got = inspect(input).score;
  const ok = got === expected;
  console.log(`${ok ? 'PASS' : 'FAIL'} ${name}: expected ${expected}, got ${got}`);
  if (!ok) failed++;
}
if (failed) process.exit(1);
console.log(`${tests.length}/${tests.length} detector tests passed`);
