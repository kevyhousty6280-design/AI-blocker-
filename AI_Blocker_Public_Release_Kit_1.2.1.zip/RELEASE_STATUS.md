# Release status — 1.2.1

Status: **Public beta / developer distribution only**.

Verified in this build pipeline: manifest JSON parses; referenced extension files exist; JavaScript syntax checks pass; detector unit tests pass; ZIP archives pass integrity checks.

Not verified: complete interactive QA in Chrome, Edge or Firefox; performance on large feeds; assistive-technology behavior; independent security audit; legal review; store acceptance; accuracy on a representative labeled media dataset.

No marketplace submission or public hosted download has been completed. The ZIPs are ready for direct manual distribution as a beta, subject to the limitations above.
